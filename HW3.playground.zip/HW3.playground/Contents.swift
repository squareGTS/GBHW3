import UIKit

//MARK - First Task & Second Task & Fourth Task
struct SportCar {
    var model = String()
    var year = Int()
    var capacityOfTrunk = Int()
    var engine = Bool()
    var windowsOpen = Bool()
    var trunkValueOfFull = Int()
    
    mutating func change(a: action) {
        self.engine = true
        self.windowsOpen = true
    }
}

struct TrunkCar {
    var model = String()
    var year = Int()
    var capacityOfTrunk = Int()
    var engine = Bool()
    var windowsOpen = Bool()
    var trunkValueOfFull = Int()
    
    mutating func change(a: action) {
        self.engine = false
        self.windowsOpen = false
    }
}

//MARK - Third Task
enum action {
    case engine(value: Bool)
    case windeows(value: Bool)
    case trunk(value: Bool)
}

//MARK - Fifth Task
var sportCar = SportCar()
var sportCar1 = SportCar()
var trunkCar = TrunkCar()
var trunkCar1 = TrunkCar()

sportCar.capacityOfTrunk = 50
sportCar.model = "Ferrari"
trunkCar.windowsOpen = true
trunkCar.model = "Man"
trunkCar1.engine = false
trunkCar1.windowsOpen = false
sportCar1.year = 1990
sportCar1.model = "BMW"
sportCar1.change(a: action.engine(value: true))

//MARK - Sixth Task
print(sportCar)
print(sportCar1)
print(trunkCar)
print(trunkCar1)
